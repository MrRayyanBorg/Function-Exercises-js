// This function takes an array of strings 
// as a single argument
// You need to test if the array contains a banana or not
// If it does return true
// If it doesn't return false 

const exercise06 = function(fruitArray) {
    // There's lots of ways to achieve this task

    // You could loop through the array 
    // You could look for a built in method
    // But watch out what the test is expecting (a boolean) to pass
  if(fruitArray.indexOf('banana')>=0){
    return true
  }else{
    return false
  }
}

module.exports = exercise06;