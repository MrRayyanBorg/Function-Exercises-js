// We have an array of objects 
// each object contains proporties of a car
// e.g. { id: 1, car_make: "Lincoln", car_model: "Navigator", car_year: 2009 },

function exercise09(inventory) {
    //you could use a loop and push to a new array 
    //or perhaps a method like map would help
  let result = inventory.map(car => car.car_year)
  return result;
    
}

module.exports = exercise09;  