// This function takes an array of strings 
// as a single argument
// You need to find the index of the banana in the array
// Assume 'banana' will appear only once in the array 

let exercise05 = function (fruitArray) {
    // there's more than one way to solve this
    // HINTS
    // You could loop over the array 
    // You could look for a built-in array method (there is one in this case)
  return fruitArray.indexOf('banana')
    

}

module.exports = exercise05;