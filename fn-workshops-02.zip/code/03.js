// This function should take 
// an id, a name and a character as arguments,
// and return an object with `id`, `name` and `character` properties.


function exercise03(x, y, z) {
    // below is a return statement. 
    // this needs to return the object 
    // with the properties as instructed

  var object = {id:x,name: y,character: z}; 
  return object
}

// nope still don't touch it.
module.exports = exercise03;