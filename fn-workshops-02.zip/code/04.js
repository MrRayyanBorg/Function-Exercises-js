// This function takes an object as a single argument
// { id: 1, name: 'T-800', character: 'Assassin'}
// you need to return a string that says `Hello, my name is {name}`
// where `{name}` is the name stored in the object

function exercise04(robot) {
    
    // how can you access the properties of the robot object? 
    // HINT
    // There's two ways to do it
    // Once you have that you need to return it as part of a string

  return `Hello, my name is `+robot.name+'.';
}

module.exports = exercise04;