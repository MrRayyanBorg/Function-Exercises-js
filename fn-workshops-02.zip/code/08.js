// In this we want to change a string to a number if 
// possible, or return that's impossible.

// This function takes two arguments
// An array of user objets
// A city as a string
// You need to return an array with only the users from that city

const exercise08 = function(userArray, city, nameBeginsWith) {
  //You could use a loop
  // Or the built in method
  // this time you need to filter by multiple properties
  return userArray.filter(user => user.city === city && user.name[0] == nameBeginsWith);
   
}

module.exports = exercise08;