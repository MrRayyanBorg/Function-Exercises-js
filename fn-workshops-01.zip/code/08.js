// In this we want to change a string to a number if 
// possible, or return that's impossible.
function isNotANumber(input){
  if(isNaN(input)){
    return true;
  }else{
    return false;
  }
}

function exercise08(string) {
  // this looks like it uses valid built-in 
  // javascript functions, but maybe these need
  // to be checked? MDN or W3 Schools might help!
  if (isNotANumber(parseInt(string))) {
    return "That's impossible!"
  } else { return parseInt(string) }
}

module.exports = exercise08;