// functions can have multiple parameters.
// here, we want to add these two parameters
// together and return the result.
// parameters can be whatever you want,
// but shouldn't start with a number or
// reserved word like 'function'.
// a parameter is abstract, belonging to the 
// time the function is defined.
// when the function is run, it is run with
// 'arguments' which are then passed into
// functions as variables.

function exercise02(inputA,inputB) {
    // this shouldn't be difficult to fix.
    // change only one character;
    // you want to add these together
  return inputA + inputB
}

// nope still don't touch it.
module.exports = exercise02;