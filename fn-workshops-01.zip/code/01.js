// functions typically have a parameters.
// a parameter is the abstract placeholder
// for what gets passed into a function.
// we can consider this the 'input'.

function exercise01(input) {
    // change the below function so it returns
    // what is being passed into it.
    // keep the 'return' statement.
  return input
}

// don't change module exports
module.exports = exercise01;